
   String currentip(){
    String current="192.168.1.74";
    return current;
  }
  

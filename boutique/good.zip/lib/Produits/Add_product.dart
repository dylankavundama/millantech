import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:stocktrue/Paternars.dart';
import 'package:stocktrue/ip.dart';
import '../main.dart';

class Addproduct extends StatefulWidget {
  const Addproduct({super.key});

  @override
  State<Addproduct> createState() => _AddproductState();
}

class _AddproductState extends State<Addproduct> {
  String? selectedValue;
  String? selectedName;
  String adress = currentip();
  List categories = [];
  bool isLoading = false;
  
  final TextEditingController nomController = TextEditingController();
    final TextEditingController detail = TextEditingController();
  final TextEditingController quantiteController = TextEditingController();
  final TextEditingController prixController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    getCategories();
  }

  @override
  void dispose() {
    nomController.dispose();
    detail.dispose();
    quantiteController.dispose();
    prixController.dispose();
    super.dispose();
  }

  Future<void> saveProduct() async {
    if (!_formKey.currentState!.validate()) return;
    if (selectedValue == null) {
      showSnackBar('Veuillez sélectionner une catégorie');
      return;
    }

    setState(() => isLoading = true);

    try {
      var url = "http://$adress/API_VENTE/PRODUIT/insertproduit.php";
      var response = await http.post(
        Uri.parse(url),
        body: {
          'designation': nomController.text,
                'detail': detail.text,
          'categorie_id': selectedValue!,
          'quantite': quantiteController.text.isNotEmpty ? quantiteController.text : '0',
          'prixu': prixController.text.isNotEmpty ? prixController.text : '0',
        },
      );

      var jsonResponse = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (jsonResponse['error'] != null) {
          showSnackBar(jsonResponse['error']);
        } else {
          showSnackBar('Produit ajouté avec succès');
          Navigator.pushAndRemoveUntil(
            context, 
            CupertinoPageRoute(builder: (context) => const Homescreen()), 
            (Route<dynamic> route) => false,
          );
        }
      } else {
        showSnackBar('Erreur lors de l\'ajout: ${jsonResponse['error'] ?? 'Erreur inconnue'}');
      }
    } catch (e) {
      showSnackBar('Erreur: ${e.toString()}');
      print('Erreur: $e');
    } finally {
      setState(() => isLoading = false);
    }
  }

  void showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> getCategories() async {
    setState(() => isLoading = true);
    
    try {
      var url = "http://$adress/API_VENTE/CATEGORIEPROD/getcategorie.php";
      var response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        setState(() => categories = jsonDecode(response.body));
      } else {
        showSnackBar('Erreur de chargement des catégories');
      }
    } catch (e) {
      showSnackBar('Erreur: ${e.toString()}');
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Nouveau Produit',
          style: TextStyle(
            fontStyle: FontStyle.normal,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                children: [
                  TextFormField(
                    controller: nomController,
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.description),
                      border: OutlineInputBorder(),
                      labelText: "Nom du produit",
                      hintText: "Entrez le nom du produit",
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Veuillez entrer un nom';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),




             TextFormField(
                    controller: detail,
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.description),
                      border: OutlineInputBorder(),
                      labelText: "detail du produit",
                      hintText: "Entrez le detail du produit",
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Veuillez entrer un detail';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),

                  DropdownButtonFormField(
                    value: selectedValue,
                    items: categories.map<DropdownMenuItem<String>>((category) {
                      return DropdownMenuItem<String>(
                        value: category['id_categorie'].toString(),
                        child: Text(category['designation'] ?? ''),
                      );
                    }).toList(),
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.category),
                      border: OutlineInputBorder(),
                      labelText: "Catégorie",
                    ),
                    onChanged: (String? value) {
                      setState(() {
                        selectedValue = value;
                        selectedName = categories.firstWhere(
                          (cat) => cat['id_categorie'].toString() == value,
                        )['designation'];
                      });
                    },
                    validator: (value) {
                      if (value == null) {
                        return 'Veuillez sélectionner une catégorie';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: quantiteController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.numbers),
                            border: OutlineInputBorder(),
                            labelText: "Quantité",
                            hintText: "0",
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextFormField(
                          controller: prixController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            prefixIcon: Icon(Icons.attach_money),
                            border: OutlineInputBorder(),
                            labelText: "Prix unitaire",
                            hintText: "0",
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: isLoading ? null : saveProduct,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 15),
                    ),
                    child: isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text('Enregistrer'),
                  ),
                ],
              ),
            ),
    );
  }
}
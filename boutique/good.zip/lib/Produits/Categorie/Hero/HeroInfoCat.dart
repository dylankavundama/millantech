
 class HeroInfoCat{
  final String title;
  final String subtitle;
  final String image;

  HeroInfoCat({required this.title, required this.subtitle, required this.image});
 }

 class HeroItemsCat{
  List<HeroInfoCat> items =[
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image1.png"),
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image2.png"),
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image3.png"),
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image4.png"),
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image5.png"),
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image6.png"),
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image7.png"),
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image8.png"),
    
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image5.png"),
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image6.png"),
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image7.png"),
    HeroInfoCat(title: "John Doe", subtitle: "john.doe@gmail.com", image: "assets/image8.png"),

  ];
 }

import 'package:flutter/material.dart';

import 'home/homeFourn.dart';

class Fournisseurs extends StatefulWidget {
  const Fournisseurs({super.key});

  @override
  State<Fournisseurs> createState() => _FournisseursState();
}

class _FournisseursState extends State<Fournisseurs> {
  @override
  Widget build(BuildContext context) {
    return const Homefourn();
  }
}
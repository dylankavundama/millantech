import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:stocktrue/HomeScreenBar.dart';
import 'package:stocktrue/Paternars.dart';
import 'package:stocktrue/ip.dart';
import '../main.dart';

class AddProduct extends StatefulWidget {
  const AddProduct({super.key});

  @override
  State<AddProduct> createState() => _AddProductState();
}

class _AddProductState extends State<AddProduct> {
  // Constants
  static const double defaultPadding = 20.0;
  static const double fieldSpacing = 20.0;
  static const double imageContainerHeight = 150.0;

  // State variables
  String? _selectedCategoryId;
  String? _selectedCategoryName;
  final String _address = currentip();
  List<Map<String, dynamic>> _categories = [];
  bool _isLoading = false;

  // Controllers
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _detailController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  // Image handling
  File? _imageFile;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _fetchCategories();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _detailController.dispose();
    _quantityController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        setState(() {
          _imageFile = File(pickedFile.path);
        });
      }
    } catch (e) {
      _showSnackBar('Erreur lors de la sélection de l\'image: ${e.toString()}');
    }
  }

  Future<void> _saveProduct() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedCategoryId == null) {
      _showSnackBar('Veuillez sélectionner une catégorie');
      return;
    }

    setState(() => _isLoading = true);

    try {
      final url =
          Uri.parse("http://$_address/API_VENTE/PRODUIT/insertproduit.php");
      final request = http.MultipartRequest("POST", url);

      // Add text fields
      request.fields['designation'] = _nameController.text.trim();
      request.fields['detail'] = _detailController.text.trim();
      request.fields['categorie_id'] = _selectedCategoryId!;
      request.fields['quantite'] = _quantityController.text.trim().isEmpty
          ? '0'
          : _quantityController.text.trim();
      request.fields['prixu'] = _priceController.text.trim().isEmpty
          ? '0'
          : _priceController.text.trim();

      // Add image if selected
      if (_imageFile != null) {
        request.files.add(
          await http.MultipartFile.fromPath('image', _imageFile!.path),
        );
      }

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);
      final jsonResponse = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (jsonResponse['status'] == 'success') {
          _showSnackBar('Produit ajouté avec succès');
          // ignore: use_build_context_synchronously
          Navigator.pushAndRemoveUntil(
            context,
            CupertinoPageRoute(builder: (context) => const Homescreen()),
            (Route<dynamic> route) => false,
          );
        } else {
          _showSnackBar(
              jsonResponse['message'] ?? 'Erreur lors de l\'ajout du produit');
        }
      } else {
        _showSnackBar('Erreur serveur: ${response.statusCode}');
      }
    } catch (e) {
      _showSnackBar('Erreur: ${e.toString()}');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _fetchCategories() async {
    setState(() => _isLoading = true);

    try {
      final url = "http://$_address/API_VENTE/CATEGORIEPROD/getcategorie.php";
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        setState(() => _categories = List<Map<String, dynamic>>.from(data));
      } else {
        _showSnackBar('Erreur de chargement des catégories');
      }
    } catch (e) {
      _showSnackBar('Erreur: ${e.toString()}');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Widget _buildFormField({
    required TextEditingController controller,
    required String labelText,
    required String hintText,
    required IconData icon,
    required String? Function(String?) validator,
    TextInputType? keyboardType,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        prefixIcon: Icon(icon),
        border: const OutlineInputBorder(),
        labelText: labelText,
        hintText: hintText,
      ),
      validator: validator,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Nouveau Produit',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(defaultPadding),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildFormField(
                      controller: _nameController,
                      labelText: "Nom du produit",
                      hintText: "Entrez le nom du produit",
                      icon: Icons.description,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Veuillez entrer un nom';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: fieldSpacing),
                    _buildFormField(
                      controller: _detailController,
                      labelText: "Détail du produit",
                      hintText: "Entrez le détail du produit",
                      icon: Icons.description,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Veuillez entrer un détail';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: fieldSpacing),
                    DropdownButtonFormField<String>(
                      value: _selectedCategoryId,
                      items:
                          _categories.map<DropdownMenuItem<String>>((category) {
                        return DropdownMenuItem<String>(
                          value: category['id_categorie'].toString(),
                          child: Text(category['designation'] ?? ''),
                        );
                      }).toList(),
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.category),
                        border: OutlineInputBorder(),
                        labelText: "Catégorie",
                      ),
                      onChanged: (String? value) {
                        setState(() {
                          _selectedCategoryId = value;
                          _selectedCategoryName = _categories.firstWhere(
                            (cat) => cat['id_categorie'].toString() == value,
                          )['designation'];
                        });
                      },
                      validator: (value) {
                        if (value == null) {
                          return 'Veuillez sélectionner une catégorie';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: fieldSpacing),
                    Row(
                      children: [
                        Expanded(
                          child: _buildFormField(
                            controller: _quantityController,
                            labelText: "Quantité",
                            hintText: "0",
                            icon: Icons.numbers,
                            validator: (value) => null,
                            keyboardType: TextInputType.number,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _buildFormField(
                            controller: _priceController,
                            labelText: "Prix unitaire",
                            hintText: "0",
                            icon: Icons.attach_money,
                            validator: (value) => null,
                            keyboardType: TextInputType.number,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: fieldSpacing),
                    GestureDetector(
                      onTap: _pickImage,
                      child: Container(
                        height: imageContainerHeight,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: _imageFile != null
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.file(
                                  _imageFile!,
                                  fit: BoxFit.cover,
                                  width: double.infinity,
                                ),
                              )
                            : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Icon(Icons.image,
                                      size: 50, color: Colors.grey),
                                  Text('Cliquer pour sélectionner une image'),
                                ],
                              ),
                      ),
                    ),
                    const SizedBox(height: fieldSpacing * 1.5),
                    ElevatedButton.icon(
                      onPressed: _isLoading ? null : _saveProduct,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        minimumSize: const Size(double.infinity, 50),
                      ),
                      icon: _isLoading
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(Icons.save),
                      label: const Text('Enregistrer'),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}

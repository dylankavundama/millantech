import 'package:flutter/material.dart';

Color orangeAccent(){
  return Colors.orangeAccent;
}
Color blacks(){
  return Colors.black;
}

Color white(){
  return Colors.white;
}
Color? orange(){
  return Colors.orange[800];
}
Color princip(){
  return const Color.fromRGBO(254, 188, 8, 1);
}


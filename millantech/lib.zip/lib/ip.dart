String currentip() {
  String current = "192.168.43.46";
  return current;
}

// ignore: non_constant_identifier_names
String Adress_IP = "http://192.168.43.46/API_VENTE/";

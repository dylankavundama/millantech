import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:stocktrue/HomeScreenBar.dart';
import '../ip.dart';

// ignore: must_be_immutable
class Detailproduit extends StatefulWidget {
  String code;
  String desigantion;
  Detailproduit(this.code, this.desigantion, {super.key});

  @override
  State<Detailproduit> createState() => _DetailproduitState();
}

class _DetailproduitState extends State<Detailproduit> {
  File? _image;
  // String adress = currentip();

  Future<List<Map<String, dynamic>>> fetchdata() async {
    final response = await http.post(
      Uri.parse('$Adress_IP/MOUVEMENT/getmv.php'),
      body: {"id": widget.code},
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body) as List;
      return data.cast<Map<String, dynamic>>();
    } else {
      throw Exception('Failed to load data');
    }
  }

  // ignore: prefer_typing_uninitialized_variables
  var selectedvalue;
  // ignore: prefer_typing_uninitialized_variables
  var selectedname;
  TextEditingController nom = TextEditingController();
  List d = [];
  List dataens = [];

  Future<void> savadatas() async {
    try {
      var url = "$Adress_IP/PRODUIT/insertproduit.php";
      Uri ulr = Uri.parse(url);
      var request = http.MultipartRequest('POST', ulr);
      request.fields['designation'] = nom.text;
      request.fields['categorie_id'] = "1";
      request.files.add(http.MultipartFile.fromBytes(
          'image1', File(_image!.path).readAsBytesSync(),
          filename: _image!.path));
      var res = await request.send();
      var response = await http.Response.fromStream(res);

      if (response.statusCode == 200) {
        bar("Success insert");
      } else {
        bar("Error insert");
      }
    } catch (e) {
      bar(e.toString());
    }
  }

  void bar(String description) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(description),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> getrecord() async {
    var url = "$Adress_IP/CATEGORIEPROD/getcategorie.php";
    try {
      var response = await http.get(Uri.parse(url));
      setState(() {
        d = jsonDecode(response.body);
      });
    } catch (e) {
      print(e);
    }
  }

  Future<void> getrecords() async {
    var url = "$Adress_IP/PRODUIT/gettrie.php";
    final response = await http.post(Uri.parse(url), body: {"id": widget.code});
    if (response.statusCode == 200) {
      setState(() {
        dataens = jsonDecode(response.body) as List;
      });
    } else {
      throw Exception('Failed to load data');
    }
  }

  Future<void> delrecord() async {
    var url = "$Adress_IP/PRODUIT/deleteproduit.php";
    final response =
        await http.post(Uri.parse(url), body: {"id_produit": widget.code});
    if (response.statusCode == 200) {
      print("Success delete");
    } else {
      throw Exception('Failed to delete data');
    }
  }

  @override
  void initState() {
    getrecord();
    getrecords();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.desigantion),
      ),
      body: SafeArea(
        child: dataens.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          margin: const EdgeInsets.all(11),
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          width: MediaQuery.of(context).size.height * 0.65,
                          height: MediaQuery.of(context).size.height * 0.90,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.withOpacity(0.5),
                                  spreadRadius: 3,
                                  blurRadius: 10,
                                  offset: const Offset(0, 3))
                            ],
                          ),
                          child: Column(
                            children: [
                              const SizedBox(height: 5),
                              Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.4,
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0),
                                  image: DecorationImage(
                                    fit: BoxFit.fill,
                                    image: NetworkImage(
                                      // "$Adress_IP/PRODUIT/images/${dataens[0]["image"]}",
                                      "${dataens[0]["image"]}",
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  dataens[0]["designation"].toString(),
                                  style: const TextStyle(
                                    fontSize: 23,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(dataens[0]["detail"]?.toString() ??
                                    "Pas de detail"),
                              ),
                              const SizedBox(height: 5),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text("Quantité actuelle :"),
                                  Text(dataens[0]["quantite"].toString()),
                                ],
                              ),
                              const SizedBox(height: 5),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text("Prix d'achat actuel :"),
                                  Text("${dataens[0]["prixu"].toString()} \$"),
                                ],
                              ),
                              const SizedBox(height: 5),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.delete),
                                    onPressed: () {
                                      delrecord();
                                      Navigator.pushAndRemoveUntil(
                                        context,
                                        CupertinoPageRoute(
                                            builder: (context) =>
                                                const HomeBarAdmin()),
                                        (Route<dynamic> route) => false,
                                      );
                                    },
                                    color: Colors.white,
                                    style: ElevatedButton.styleFrom(
                                      elevation: 0,
                                      backgroundColor: Colors.redAccent,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

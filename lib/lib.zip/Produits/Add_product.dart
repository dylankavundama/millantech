import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:stocktrue/HomeScreenBar.dart';
import 'package:stocktrue/ip.dart';

class AddProduct extends StatefulWidget {
  const AddProduct({super.key});

  @override
  State<AddProduct> createState() => _AddProductState();
}

class _AddProductState extends State<AddProduct> {
  static const double defaultPadding = 20.0;
  static const double fieldSpacing = 16.0;
  static const double imageContainerHeight = 180.0;
  static const double buttonHeight = 50.0;
  static const int maxImageSizeMB = 2;

  String? _selectedCategoryId;
  List<Map<String, dynamic>> _categories = [];
  bool _isLoading = false;
  bool _isSaving = false;

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _detailController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _imageUrlController = TextEditingController(); // Nouveau contrôleur pour l'URL
  final _formKey = GlobalKey<FormState>();

  File? _imageFile;
  final ImagePicker _picker = ImagePicker();
  String? _imageError;
  String? _currentImageUrl; // Pour afficher l'image depuis l'URL

  @override
  void initState() {
    super.initState();
    _fetchCategories();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _detailController.dispose();
    _quantityController.dispose();
    _priceController.dispose();
    _imageUrlController.dispose(); // Libérer le nouveau contrôleur
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final pickedFile = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (pickedFile != null) {
        final fileSize = await File(pickedFile.path).length();
        if (fileSize > maxImageSizeMB * 1024 * 1024) {
          setState(() {
            _imageError = 'L\'image ne doit pas dépasser $maxImageSizeMB MB';
          });
          return;
        }
        setState(() {
          _imageFile = File(pickedFile.path);
          _imageError = null;
          _imageUrlController.clear(); // Effacer l'URL si une image est sélectionnée
          _currentImageUrl = null;
        });
      }
    } catch (e) {
      _showSnackBar('Erreur lors de la sélection de l\'image');
      debugPrint('Image picker error: $e');
    }
  }

  // Permet de vider l'image sélectionnée ou l'URL saisie
  void _clearImageSelection() {
    setState(() {
      _imageFile = null;
      _imageUrlController.clear();
      _currentImageUrl = null;
      _imageError = null;
    });
  }

  Future<void> _saveProduct() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedCategoryId == null) {
      _showSnackBar('Veuillez sélectionner une catégorie');
      return;
    }
    // L'erreur d'image est déjà gérée par le validateur de l'URL ou la sélection de fichier
    // if (_imageError != null) {
    //   _showSnackBar(_imageError!);
    //   return;
    // }

    setState(() => _isSaving = true);

    try {
      final uri = Uri.parse("https://www.easykivu.com/phonexa/PRODUIT/insertproduit.php");
      final request = http.MultipartRequest("POST", uri);

      request.fields.addAll({
        'designation': _nameController.text.trim(),
        'detail': _detailController.text.trim(),
        'categorie_id': _selectedCategoryId!,
        'quantite': _quantityController.text.trim().isEmpty ? '0' : _quantityController.text.trim(),
        'prixu': _priceController.text.trim().isEmpty ? '0' : _priceController.text.trim(),
      });

      // Logique pour envoyer l'image : soit le fichier, soit l'URL
      if (_imageFile != null) {
        final fileSize = await _imageFile!.length();
        if (fileSize > maxImageSizeMB * 1024 * 1024) { // Correction de la taille ici (1024*1024 au lieu de 10024*10024)
          throw Exception('L\'image est trop volumineuse');
        }
        request.files.add(
          await http.MultipartFile.fromPath(
            'image', // Nom du champ attendu par le serveur pour le fichier
            _imageFile!.path,
            filename: 'product_${DateTime.now().millisecondsSinceEpoch}.${_imageFile!.path.split('.').last}',
          ),
        );
      } else if (_imageUrlController.text.trim().isNotEmpty) {
        // Si un lien URL est fourni, ajoutez-le comme un champ de texte
        // Vérifier si l'URL est valide avant de l'envoyer
        if (Uri.tryParse(_imageUrlController.text.trim())?.hasAbsolutePath == true) {
          request.fields['image_url'] = _imageUrlController.text.trim(); // Nom du champ pour l'URL
        } else {
          throw Exception('L\'URL de l\'image est invalide.');
        }
      }

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();

      dynamic jsonResponse;
      try {
        jsonResponse = jsonDecode(responseBody);
      } catch (_) {
        throw Exception('Réponse serveur invalide');
      }

      if (response.statusCode == 200) {
        if (jsonResponse['status'] == 'success') {
          _showSnackBar('Produit ajouté avec succès');
          if (!mounted) return;
          Navigator.pushAndRemoveUntil(
            context,
            CupertinoPageRoute(builder: (_) => const HomeMillan()),
            (route) => false,
          );
        } else {
          throw Exception(jsonResponse['message'] ?? 'Erreur inconnue');
        }
      } else {
        throw Exception('Erreur serveur: ${response.statusCode}');
      }
    } catch (e) {
      _showSnackBar('Erreur: ${e.toString().replaceAll('Exception: ', '')}');
      debugPrint('Save product error: $e');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(label: 'OK', onPressed: () {}),
      ),
    );
  }

  Future<void> _fetchCategories() async {
    if (_isLoading) return;

    setState(() => _isLoading = true);

    try {
      final response = await http.get(
        Uri.parse("$Adress_IP/CATEGORIEPROD/getcategorie.php"),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data is List) {
          setState(() {
            _categories = List<Map<String, dynamic>>.from(data);
          });
        } else {
          throw Exception('Format de données inattendu');
        }
      } else {
        throw Exception('Statut HTTP ${response.statusCode}');
      }
    } catch (e) {
      _showSnackBar('Erreur de chargement des catégories');
      debugPrint('Fetch categories error: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Widget _buildFormField({
    required TextEditingController controller,
    required String labelText,
    required String hintText,
    required IconData icon,
    required String? Function(String?) validator,
    TextInputType? keyboardType,
    int? maxLength,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      maxLength: maxLength,
      decoration: InputDecoration(
        prefixIcon: Icon(icon),
        border: const OutlineInputBorder(),
        labelText: labelText,
        hintText: hintText,
        counterText: '',
      ),
      validator: validator,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nouveau Produit', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(defaultPadding),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildFormField(
                      controller: _nameController,
                      labelText: "Nom du produit*",
                      hintText: "Entrez le nom du produit",
                      icon: Icons.description,
                      maxLength: 100,
                      validator: (value) =>
                          (value == null || value.trim().isEmpty) ? 'Ce champ est obligatoire' : null,
                    ),
                    const SizedBox(height: fieldSpacing),
                    _buildFormField(
                      controller: _detailController,
                      labelText: "Détail du produit*",
                      hintText: "Entrez le détail du produit",
                      icon: Icons.info_outline,
                      maxLength: 255,
                      validator: (value) =>
                          (value == null || value.trim().isEmpty) ? 'Ce champ est obligatoire' : null,
                    ),
                    const SizedBox(height: fieldSpacing),
                    DropdownButtonFormField<String>(
                      value: _selectedCategoryId,
                      isExpanded: true,
                      items: _categories.map((category) {
                        return DropdownMenuItem<String>(
                          value: category['id_categorie'].toString(),
                          child: Text(category['designation'] ?? 'Inconnu', overflow: TextOverflow.ellipsis),
                        );
                      }).toList(),
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.category),
                        border: OutlineInputBorder(),
                        labelText: "Catégorie*",
                      ),
                      onChanged: (value) => setState(() => _selectedCategoryId = value),
                      validator: (value) => value == null ? 'Ce champ est obligatoire' : null,
                    ),
                    const SizedBox(height: fieldSpacing),
                    Row(
                      children: [
                        Expanded(
                          child: _buildFormField(
                            controller: _quantityController,
                            labelText: "Quantité",
                            hintText: "0",
                            icon: Icons.inventory_2,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            validator: (value) {
                              if (value == null || value.isEmpty) return null;
                              final num = double.tryParse(value.replaceAll(',', '.'));
                              if (num == null) return 'Nombre invalide';
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: fieldSpacing),
                        Expanded(
                          child: _buildFormField(
                            controller: _priceController,
                            labelText: "Prix unitaire",
                            hintText: "0",
                            icon: Icons.attach_money,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            validator: (value) {
                              if (value == null || value.isEmpty) return null;
                              final num = double.tryParse(value.replaceAll(',', '.'));
                              if (num == null) return 'Nombre invalide';
                              if (num < 0) return 'Le prix ne peut être négatif';
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: fieldSpacing),
                    // Nouveau champ pour l'URL de l'image
                    _buildFormField(
                      controller: _imageUrlController,
                      labelText: "Lien de l'image (optionnel)",
                      hintText: "Collez l'URL de l'image ici",
                      icon: Icons.link,
                      keyboardType: TextInputType.url,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return null; // Non obligatoire
                        }
                        // Validation simple d'URL
                        final uri = Uri.tryParse(value.trim());
                        if (uri == null || !uri.hasAbsolutePath) {
                          return 'URL invalide';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: fieldSpacing),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Image du produit (optionnel)', style: Theme.of(context).textTheme.bodyMedium),
                        const SizedBox(height: 8),
                        GestureDetector(
                          onTap: _pickImage,
                          child: Container(
                            height: imageContainerHeight,
                            decoration: BoxDecoration(
                              border: Border.all(color: _imageError != null ? Colors.red : Colors.grey.shade400),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: (_imageFile != null) // Si un fichier est sélectionné
                                ? Stack(
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(8),
                                        child: Image.file(_imageFile!, fit: BoxFit.cover, width: double.infinity),
                                      ),
                                      Positioned(
                                        top: 8,
                                        right: 8,
                                        child: IconButton(
                                          icon: const Icon(Icons.close, color: Colors.white),
                                          onPressed: _clearImageSelection, // Utiliser la fonction pour vider
                                        ),
                                      ),
                                    ],
                                  )
                                : (_imageUrlController.text.trim().isNotEmpty && // Si l'URL n'est pas vide
                                    Uri.tryParse(_imageUrlController.text.trim())?.hasAbsolutePath == true // ET l'URL est valide
                                  )
                                    ? Stack(
                                        children: [
                                          ClipRRect(
                                            borderRadius: BorderRadius.circular(8),
                                            child: Image.network(
                                              _imageUrlController.text.trim(),
                                              fit: BoxFit.cover,
                                              width: double.infinity,
                                              errorBuilder: (context, error, stackTrace) =>
                                                  const Center(child: Text('Erreur chargement image')),
                                            ),
                                          ),
                                          Positioned(
                                            top: 8,
                                            right: 8,
                                            child: IconButton(
                                              icon: const Icon(Icons.close, color: Colors.white),
                                              onPressed: _clearImageSelection, // Utiliser la fonction pour vider
                                            ),
                                          ),
                                        ],
                                      )
                                    : Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.image, size: 50, color: Colors.grey.shade400),
                                          const SizedBox(height: 10),
                                          const Text('Cliquez pour sélectionner une image ou utilisez l\'URL'),
                                        ],
                                      ),
                          ),
                        ),
                        if (_imageError != null)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(_imageError!, style: const TextStyle(color: Colors.red)),
                          ),
                      ],
                    ),
                    const SizedBox(height: fieldSpacing * 2),
                    SizedBox(
                      height: buttonHeight,
                      child: ElevatedButton(
                        onPressed: _isSaving ? null : _saveProduct,
                        child: _isSaving
                            ? const CircularProgressIndicator(color: Colors.white)
                            : const Text('Enregistrer', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}